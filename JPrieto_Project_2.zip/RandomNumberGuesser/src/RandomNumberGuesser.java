import java.util.Random;

import java.util.Scanner;


/*
 * Class: CMSC203 
 * Instructor: Gary Thai
 * Description: This class work a s a game for the user that has 7 tries to guess a random generated number.
 * Due: 02/23/23
 * Platform/compiler: Eclipse 
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Juan Prieto_
*/

public class RandomNumberGuesser

{
	
	
	public static void main(String[] args) 
{
		
		int nextGuess;
		int highGuess=100;
		int lowGuess=0;
		int guess;
		int randNumber;
		int tries = 0;
		boolean approved;
		
		String newGame;
		
		Scanner keyboard = new Scanner(System.in);
		 
		 RNG game = new RNG();
		
do {
		System.out.println ("This application generates a random integer between 0 and 100");
		System.out.println ("and asks the user to guess repeatedly until they guess correctly.");
		
		game.resetCount();
		game.rand();
		randNumber = game.rand();
		
		
		
	do {
		
		System.out.print("Write your next guess: ");
		
		nextGuess = keyboard.nextInt();
		approved = game.inputValidation(nextGuess, lowGuess, highGuess);
		System.out.println("Number of guesses:" + game.getCount());
		
	
	
		if (nextGuess == randNumber)
		{
		
			System.out.println("Congratulations, you guessed correctly.");
			System.out.println("Try again? (yes or no)");
					
		}	
		else 
		{
			
			if (nextGuess < randNumber)
			{
				
				
				lowGuess = nextGuess;
				
				
				
				do {
					approved = game.inputValidation(nextGuess, lowGuess, highGuess);
				System.out.println("Your guess " + nextGuess + " is too low. Try again: ");
				System.out.println("Number of guesses:" + game.getCount());
				
				System.out.println ("Enter your next guess between: " + lowGuess + " and " + highGuess );
				System.out.print ("Try again: ");
				
				nextGuess = keyboard.nextInt();
				} while (nextGuess < lowGuess);
				
				
				
				while (nextGuess < lowGuess || nextGuess > 100)
				{
				approved = game.inputValidation(nextGuess, lowGuess, highGuess);
				
				nextGuess = keyboard.nextInt();
				} 
				
				
				while (nextGuess > randNumber || nextGuess  > highGuess) 
				{
					approved = game.inputValidation(nextGuess, lowGuess, highGuess);
					System.out.println("Your guess " + nextGuess + " is too high. Try again: ");
					System.out.println("Number of guesses:" + game.getCount());
					
					System.out.println ("Enter your next guess between: " + lowGuess + " and " + highGuess );
					System.out.print ("Try again: ");
					
					nextGuess = keyboard.nextInt();
				
				} 
				
				
			}
			// if the guess is higher than the randnumber.
			else if (nextGuess < randNumber)
			{
	
					highGuess = nextGuess;
					
					do {
					approved = game.inputValidation(nextGuess, lowGuess, highGuess);
					System.out.println("Your guess " + nextGuess + " is too low. Try again: ");
					System.out.println("Number of guesses:" + game.getCount());
					
					System.out.println ("Enter your next guess between: " + lowGuess + " and " + highGuess );
					System.out.print ("Try again: ");
					
					nextGuess = keyboard.nextInt();
					} while (nextGuess > highGuess);
					
					
					
					do {
					approved = game.inputValidation(nextGuess, lowGuess, highGuess);
					
					nextGuess = keyboard.nextInt();
					} while (nextGuess < 0 || nextGuess > highGuess);
					
					
					do 
					{
						approved = game.inputValidation(nextGuess, lowGuess, highGuess);
						System.out.println("Your guess " + nextGuess + " is too high. Try again: ");
						System.out.println("Number of guesses:" + game.getCount());
						
						System.out.println ("Enter your next guess between: " + lowGuess + " and " + highGuess );
						System.out.print ("Try again: ");
						
						nextGuess = keyboard.nextInt();
					
					} while (nextGuess > lowGuess || nextGuess  > randNumber);
			}
			
		}
		
		}while (game.getCount() < 7);
		
		
		
			System.out.println("You have exceed the number of guesse.");
			System.out.println ("Want to try again? (yes or no)");
			newGame = keyboard.nextLine();
		
}while (newGame == "yes");	
	
	
	}	
	
	
	
	
}
